package com.hyperglass.launcher

import android.app.Activity
import android.app.WallpaperManager
import android.content.Intent
import android.content.pm.ResolveInfo
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.GridLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : Activity() {
    private lateinit var root: FrameLayout
    private lateinit var content: LinearLayout
    private var drawerOpen = false
    private var startY = 0f
    private var allApps: List<ResolveInfo> = emptyList()
    private val text = Color.WHITE
    private val muted = 0xD9FFFFFF.toInt()
    private val glass = 0x442D2940

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.rgb(25, 13, 42)
        window.navigationBarColor = Color.rgb(16, 13, 25)
        window.decorView.systemUiVisibility = 0
        allApps = loadApps()
        buildHome()
    }

    private fun loadApps(): List<ResolveInfo> {
        val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        return packageManager.queryIntentActivities(intent, 0)
            .filter { it.activityInfo.packageName != packageName }
            .sortedBy { it.loadLabel(packageManager).toString().lowercase(Locale.getDefault()) }
    }

    private fun bg(color: Int, radius: Float, stroke: Int = 0x55FFFFFF): GradientDrawable =
        GradientDrawable().apply {
            setColor(color)
            cornerRadius = radius
            setStroke(dp(1), stroke)
        }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun buildHome() {
        drawerOpen = false
        root = FrameLayout(this)
        root.background = GradientDrawable(
            GradientDrawable.Orientation.TL_BR,
            intArrayOf(0xFF21133B.toInt(), 0xFF39205A.toInt(), 0xFF101020.toInt(), 0xFF080910.toInt())
        )
        content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(18), dp(20), dp(12))
        }
        root.addView(content, FrameLayout.LayoutParams(-1, -1))

        val top = TextView(this).apply {
            text = "HYPERGLASS  •  ${SimpleDateFormat("EEE, d MMM", Locale.getDefault()).format(Date()).uppercase()}"
            setTextColor(muted); textSize = 12f; letterSpacing = .12f
        }
        content.addView(top)

        val clock = TextView(this).apply {
            text = SimpleDateFormat("h:mm", Locale.getDefault()).format(Date())
            setTextColor(text); textSize = 58f; typeface = Typeface.create("sans-serif-light", Typeface.NORMAL)
            setPadding(0, dp(28), 0, 0)
        }
        content.addView(clock)
        val date = TextView(this).apply {
            text = SimpleDateFormat("EEEE, d MMMM", Locale.getDefault()).format(Date())
            setTextColor(muted); textSize = 15f
        }
        content.addView(date)

        val search = EditText(this).apply {
            hint = "Search apps"
            setHintTextColor(0xBFFFFFFF.toInt()); setTextColor(text); textSize = 15f
            singleLine = true
            background = bg(glass, dp(28).toFloat())
            setPadding(dp(18), 0, dp(18), 0)
        }
        val searchParams = LinearLayout.LayoutParams(-1, dp(52)).apply { topMargin = dp(28); bottomMargin = dp(20) }
        content.addView(search, searchParams)
        search.setOnEditorActionListener { v, _, _ ->
            val q = v.text.toString().trim()
            if (q.isNotEmpty()) showDrawer(q)
            true
        }

        val label = TextView(this).apply {
            text = "Favourites"; setTextColor(text); textSize = 18f
            typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
        }
        content.addView(label)
        val favs = chooseFavourites()
        content.addView(appGrid(favs.take(8), 4))

        val spacer = View(this)
        content.addView(spacer, LinearLayout.LayoutParams(1, 0, 1f))

        val dock = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER
            background = bg(0x553D3A4D, dp(30).toFloat(), 0x66FFFFFF)
            setPadding(dp(8), dp(10), dp(8), dp(10))
        }
        chooseFavourites().take(5).forEach { info -> dock.addView(appCell(info, true), LinearLayout.LayoutParams(0, dp(64), 1f)) }
        content.addView(dock, LinearLayout.LayoutParams(-1, dp(82)))

        val hint = TextView(this).apply {
            text = "Swipe up for all apps"; setTextColor(0x99FFFFFF.toInt()); textSize = 11f; gravity = Gravity.CENTER
            setPadding(0, dp(12), 0, dp(4))
        }
        content.addView(hint)
        root.setOnTouchListener { _, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> { startY = event.y; true }
                MotionEvent.ACTION_UP -> {
                    if (startY - event.y > dp(55)) showDrawer("")
                    true
                }
                else -> true
            }
        }
        setContentView(root)
    }

    private fun chooseFavourites(): List<ResolveInfo> {
        val preferred = listOf("com.google.android.dialer", "com.google.android.apps.messaging", "com.android.chrome", "com.google.android.youtube", "com.whatsapp")
        val chosen = preferred.mapNotNull { p -> allApps.firstOrNull { it.activityInfo.packageName == p } }
        return (chosen + allApps.filterNot { it in chosen }).distinct()
    }

    private fun appGrid(apps: List<ResolveInfo>, columns: Int): GridLayout {
        val grid = GridLayout(this).apply { columnCount = columns; useDefaultMargins = false }
        apps.forEach { grid.addView(appCell(it, false), GridLayout.LayoutParams().apply {
            width = 0; height = dp(100); columnSpec = GridLayout.spec(GridLayout.UNDEFINED, 1f)
            setMargins(dp(2), dp(12), dp(2), dp(4))
        }) }
        return grid
    }

    private fun appCell(info: ResolveInfo, dock: Boolean): LinearLayout {
        val cell = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER; isClickable = true; isFocusable = true }
        val icon = ImageView(this).apply {
            setImageDrawable(info.loadIcon(packageManager)); scaleType = ImageView.ScaleType.FIT_CENTER
            background = bg(0x33FFFFFF, dp(19).toFloat(), 0x22FFFFFF)
            setPadding(dp(7), dp(7), dp(7), dp(7))
        }
        cell.addView(icon, LinearLayout.LayoutParams(dp(if (dock) 42 else 50), dp(if (dock) 42 else 50)))
        if (!dock) {
            val name = TextView(this).apply {
                text = info.loadLabel(packageManager); setTextColor(text); textSize = 11f
                gravity = Gravity.CENTER; maxLines = 1; ellipsize = android.text.TextUtils.TruncateAt.END
            }
            cell.addView(name, LinearLayout.LayoutParams(-1, dp(28)))
        }
        cell.setOnClickListener { launch(info) }
        return cell
    }

    private fun showDrawer(filter: String) {
        drawerOpen = true
        root = FrameLayout(this).apply {
            background = GradientDrawable(GradientDrawable.Orientation.TL_BR,
                intArrayOf(0xFF21152F.toInt(), 0xFF171522.toInt(), 0xFF090A11.toInt()))
        }
        val column = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(20), dp(22), dp(20), dp(12)) }
        root.addView(column)
        val header = TextView(this).apply { text = "All apps"; textSize = 30f; setTextColor(text); typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL) }
        column.addView(header)
        val input = EditText(this).apply {
            hint = "Find an app"; setHintTextColor(0xBFFFFFFF.toInt()); setTextColor(text); textSize = 15f
            background = bg(glass, dp(26).toFloat()); setPadding(dp(18), 0, dp(18), 0); singleLine = true
            setText(filter); setSelection(this.text.length)
        }
        column.addView(input, LinearLayout.LayoutParams(-1, dp(50)).apply { topMargin = dp(18); bottomMargin = dp(12) })
        val scroll = ScrollView(this)
        val list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        scroll.addView(list)
        column.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        fun populate(query: String) {
            list.removeAllViews()
            val filtered = allApps.filter { it.loadLabel(packageManager).toString().contains(query, true) }
            list.addView(appGrid(filtered, 4))
            if (filtered.isEmpty()) list.addView(TextView(this).apply { text = "No apps found"; setTextColor(muted); gravity = Gravity.CENTER; setPadding(0, dp(30), 0, 0) })
        }
        populate(filter)
        input.addTextChangedListener(object : android.text.TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) { populate(s?.toString().orEmpty()) }
            override fun afterTextChanged(s: android.text.Editable?) {}
        })
        val back = TextView(this).apply { text = "‹   Back to home"; textSize = 15f; setTextColor(text); gravity = Gravity.CENTER_VERTICAL; setPadding(0, dp(12), 0, dp(8)); setOnClickListener { buildHome() } }
        column.addView(back, LinearLayout.LayoutParams(-1, dp(46)))
        setContentView(root)
    }

    private fun launch(info: ResolveInfo) {
        val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
            .setClassName(info.activityInfo.packageName, info.activityInfo.name)
        try { startActivity(intent) } catch (_: Exception) { Toast.makeText(this, "Unable to open app", Toast.LENGTH_SHORT).show() }
    }

    @Deprecated("Deprecated in Android API; retained for launcher back behavior")
    override fun onBackPressed() {
        if (drawerOpen) buildHome() else super.onBackPressed()
    }
}
