# HyperGlass Launcher (prototype 0.1.0)

A lightweight, native Kotlin Android HOME launcher prototype with a HyperOS-inspired layout and translucent Liquid Glass-inspired surfaces. It is not Xiaomi software and does not modify HyperOS system components.

## Current features
- Declares itself as an Android HOME/default launcher.
- Lists launchable apps using Android's package manager.
- Launches apps, has an app drawer with live filtering, swipe-up gesture, and a favourites/dock area.
- Uses native Android views; no third-party runtime dependencies.
- Supports Android 8.0+ (minSdk 26); configured to compile against Android 16 (API 36).

## Build an installable APK
1. Install Android Studio (current stable) on a computer.
2. Install Android SDK Platform 36 and a compatible Android SDK Build-Tools version from SDK Manager.
3. Open this folder (`HyperGlassLauncher`) in Android Studio and allow Gradle sync. The project uses Android Gradle Plugin 8.9.1 and Kotlin 2.1.10; Android Studio/Gradle may download these build components.
4. Choose **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
5. The debug APK will be at `app/build/outputs/apk/debug/app-debug.apk`.
6. Transfer it to the POCO and install it. If Android asks, allow installation from the app used to open the APK.
7. Press Home and select **HyperGlass Launcher**. You can switch back to POCO Launcher in Settings > Apps > Default apps > Home app (menu names may vary by HyperOS build).

## Notes / limitations in this prototype
- This is a first functional prototype, not a polished HyperOS clone.
- The clock/date are drawn at launch and are not yet live-updating.
- Wallpaper is currently a gradient; wallpaper picker, widget hosting, folder editing, icon packs, drag/drop, persistent favourites, gesture customization, animation tuning, and a settings screen are planned next.
- A launcher cannot replace the system control centre, notification shade, lock screen, or system animations without privileged/system permissions.
- Some Xiaomi builds may restrict third-party HOME apps. If the launcher does not appear in the Home app chooser, check HyperOS default-app restrictions and battery/background settings. Keep POCO Launcher installed as fallback.
